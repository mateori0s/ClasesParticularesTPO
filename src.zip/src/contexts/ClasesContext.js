import React from 'react';

const ClaseContext = React.createContext({clase: {}});

export {ClaseContext};